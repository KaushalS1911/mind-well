import React from 'react';
import EngagementFramework from "../../components/Services/EngagementFramework.jsx";
import {Box} from "@mui/material";
import Shape from "../../components/Services/shape.jsx";
import Esop from "../../components/Services/esop.jsx";

function Services() {
    return (
        <>
            <EngagementFramework/>
        </>
    );
}

export default Services;