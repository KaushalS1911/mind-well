import React from 'react';
import Getintouch from "../../components/Contact/getintouch.jsx";
import Map from "../../components/Contact/map.jsx";

function Contact() {
    return (
        <>
            <Getintouch/>
            <Map/>
        </>
    );
}

export default Contact;