import React, {useState} from "react";
import {Box, Grid, Container, TextField, DialogContent, DialogTitle, Dialog, Button, IconButton} from "@mui/material";
import {useNavigate} from "react-router-dom";
import BoltIcon from "@mui/icons-material/Bolt";
import img1 from "../../assets/images/Resources/Assessments/Exam.jpg";
import img2 from "../../assets/images/Resources/Assessments/Shape_K12.jpeg";
import img3 from "../../assets/images/Resources/Assessments/General_Stress_Anxiety.jpeg";
import img4 from "../../assets/images/Resources/Assessments/Emotional_Awareness.jpg";
import img5 from "../../assets/images/Resources/Assessments/Academic_Stress.jpg";
import img6 from "../../assets/images/Resources/Assessments/Self_Esteem_Scale.jpg";
import img7 from "../../assets/images/Resources/Assessments/Work_Life_Balance.jpg";
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import ShareIcon from '@mui/icons-material/Share';
import { ToastContainer, toast } from 'react-toastify';

function Assessments() {
    const navigate = useNavigate();
    const [selectedIndex, setSelectedIndex] = useState(null);
    const [open, setOpen] = useState(false);
    const [assessmentUrl, setAssessmentUrl] = useState("");

    const handleAssessmentClick = (index) => {
        setSelectedIndex(index);
        const url = assessments[index].url;
        setAssessmentUrl(window.location.origin + url);
        navigate(url);
    };

    const handleOpen = (index) => {
        const url = assessments[index].url;
        setAssessmentUrl(window.location.origin + url);
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const handleCopy = () => {
        navigator.clipboard.writeText(assessmentUrl);
        const notify = () => toast("Copied!");
        notify();
    };


    const assessments = [
        {
            img: img1,
            title: "Exam Stress Gauge",
            subTitle: "(Age 18-21)",
            description: "Evaluate your anxiety levels and identify potential triggers.",
            url: '/assessments/exam-stress',
            questions: "20 questions",
            time: "~ 10 min"
        },
        {
            img: img3,
            title: "General Stress & Anxiety",
            description: "Measure your current stress levels and coping mechanisms.",
            url: '/assessments/general-stress',
            questions: "12 questions",
            time: "~ 6 min"
        },
        {
            img: img4,
            title: "Emotional Awareness & Regulation",
            subTitle: "(Age 4-10)",
            description: "Understand your emotional intelligence and self-awareness.",
            url: '/assessments/emotional-awareness',
            questions: "15 questions",
            time: "~ 7 min"
        },
        {
            img: img5,
            title: "Academic Stress",
            subTitle: "(Age 16-25)",
            description: "Analyze stress levels related to academic pressure and workload.",
            url: '/assessments/academic-stress',
            questions: "20 questions",
            time: "~ 10 min"
        },
        {
            img: img6,
            title: "Self-Esteem Scale for Pre-Adolescents",
            subTitle: "(Age 11-13)",
            description: "Measure your self-esteem and confidence levels.",
            url: '/assessments/self-esteem-scale',
            questions: "20 questions",
            time: "~ 10 min"
        },
        {
            img: img7,
            title: "Work-Life Balance",
            subTitle: "(Age 21+)",
            description: "Evaluate your balance between work and personal life.",
            url: '/assessments/work-life-balance',
            questions: "15 questions",
            time: "~ 7 min"
        },
    ];

    return (
        <Container maxWidth="xl">
            <Box sx={{ p: "96px 0", mt: {md: 5, xs: 0}}}>
                <Box sx={{p: {xs: 3, md: 5}, bgcolor: "#012765", borderRadius: 3, color: "#fff"}}>
                    <Grid container spacing={3}>
                        <Grid item xs={12} md={12}>
                            <Box sx={{display: "flex", alignItems: "center", mb: "24px"}}>
                                <Box
                                    sx={{
                                        bgcolor: "#FE6A00",
                                        color: "#fff",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        borderRadius: "30px",
                                        padding: "10px",
                                        fontSize: {xs: 16, md: 20},
                                        mr: 2,
                                    }}
                                >
                                    <BoltIcon/>
                                </Box>
                                <Box className={"Montserrat"}
                                     sx={{fontWeight: "700", fontSize: {xs: "24px", md: "30px"}}}>
                                    Self Assessments
                                </Box>
                            </Box>
                            <Box fontSize={{xs: 14, md: 18}} color="#CBD5E1" sx={{mb: "40px"}}>
                                Take our scientifically-validated assessments to gain insights into your mental health
                                and determine whether you might benefit from professional support.
                            </Box>
                            <Grid container spacing={2}>
                                <Grid container spacing={2}>
                                    {assessments.map((assessment, index) => (
                                        <Grid item xs={12} sm={6} md={4} key={index}>
                                            <Box
                                                sx={{
                                                    p: 2,
                                                    borderRadius: 2,
                                                    bgcolor: "#FFFFFF1A",
                                                    color: "#fff",
                                                    height: "100%",
                                                    display: "flex",
                                                    flexDirection: "column",
                                                }}
                                            >
                                                <Box display="flex" alignItems="center"
                                                     sx={{justifyContent: "space-Between"}} mb={1.5}>
                                                    <Box sx={{display: "flex", alignItems: "center"}}>
                                                        <img
                                                            src={assessment.img}
                                                            alt={assessment.title}
                                                            style={{
                                                                width: 40,
                                                                height: 40,
                                                                borderRadius: "50%",
                                                                marginRight: 12,
                                                            }}
                                                        />
                                                        <Box display="flex" flexDirection="column">
                                                            <Box fontWeight={600} sx={{
                                                                fontSize: {xs: 16, md: 17},
                                                                display: "flex",
                                                                alignItems: "center"
                                                            }}>
                                                                {assessment.icon} <span
                                                                style={{marginLeft: 6}}>{assessment.title}</span>
                                                            </Box>
                                                            {assessment.subTitle && (
                                                                <Box sx={{
                                                                    fontSize:14,
                                                                    color: "#fff",
                                                                    fontWeight: 400,
                                                                }}>
                                                                    {assessment.subTitle}
                                                                </Box>
                                                            )}
                                                        </Box>
                                                    </Box>
                                                    <IconButton
                                                        onClick={() => handleOpen(index)}
                                                        sx={{
                                                            backgroundColor: "#FE6A00",
                                                            color: "#fff",
                                                            p: 0.3,
                                                            borderRadius: 2,
                                                            "&:hover": {
                                                                backgroundColor: "#FE6A00"
                                                            }
                                                        }}
                                                    >
                                                        <ShareIcon/>
                                                    </IconButton>

                                                </Box>

                                                <Box color="#CBD5E1" mb={2} sx={{fontSize: 14}}>
                                                    {assessment.description}
                                                </Box>

                                                <Box display="flex" gap={1} alignItems="center" mt={2}>
                                                    <Box
                                                        sx={{
                                                            bgcolor: "#FFFFFF33",
                                                            px: 1.5,
                                                            py: 0.5,
                                                            fontSize: 12,
                                                            color: "#fff",
                                                            borderRadius: 10,
                                                        }}
                                                    >
                                                        {assessment.questions}
                                                    </Box>
                                                    <Box
                                                        sx={{
                                                            bgcolor: "#FFFFFF33",
                                                            px: 1.5,
                                                            py: 0.5,
                                                            fontSize: 12,
                                                            color: "#fff",
                                                            borderRadius: 10,
                                                        }}
                                                    >
                                                        {assessment.time}
                                                    </Box>
                                                </Box>

                                                <Box sx={{flexGrow: 1}}/>

                                                <Box
                                                    sx={{
                                                        alignSelf: "flex-end",
                                                        fontWeight: 400,
                                                        fontSize: 14,
                                                        color: "#FE6A00",
                                                        display: "flex",
                                                        alignItems: "center",
                                                        transition: "0.5s",
                                                        cursor: "pointer",
                                                        mt: {xs: 3},
                                                        '&:hover': {
                                                            color: "#fff",
                                                        },
                                                    }}
                                                    onClick={() => handleAssessmentClick(index)}
                                                >
                                                    TAKE ASSESSMENT <KeyboardDoubleArrowRightIcon/>
                                                </Box>
                                            </Box>
                                        </Grid>
                                    ))}
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </Box>
            </Box>
            <Dialog open={open}  onClose={handleClose}>
                <DialogTitle>Share this URL</DialogTitle>
                <DialogContent>
                    <TextField fullWidth value={assessmentUrl} InputProps={{readOnly: true}} sx={{mt: 1}}/>
                    <Button variant="contained" onClick={handleCopy} sx={{mt: 2}}>Copy URL</Button>
                    <ToastContainer />
                </DialogContent>
            </Dialog>
        </Container>
    );
}

export default Assessments;




